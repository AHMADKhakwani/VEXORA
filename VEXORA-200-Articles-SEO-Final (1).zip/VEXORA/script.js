(() => {
 const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
 const root=document.documentElement;
 const menu=$('.menu-toggle'), nav=$('.nav');
 if(menu&&nav){menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));menu.textContent=open?'×':'☰'});$$('.nav a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menu.setAttribute('aria-expanded','false');menu.textContent='☰'}));}
 // Persistent dark/light appearance across the homepage, policy pages and article pages.
 const theme=$('.theme-toggle');
 function applyTheme(mode,save=true){
   const light=mode==='light';
   root.classList.toggle('theme-light',light);
   if(theme){theme.textContent=light?'☾':'☼';theme.setAttribute('aria-label',light?'Switch to dark theme':'Switch to light theme');theme.title=light?'Switch to dark theme':'Switch to light theme';}
   const meta=$('meta[name="theme-color"]');if(meta)meta.content=light?'#f5f7fc':'#070d19';
   if(save){try{localStorage.setItem('vexora-theme',light?'light':'dark');}catch(e){}}
 }
 let saved='dark';try{saved=localStorage.getItem('vexora-theme')||'dark';}catch(e){}
 applyTheme(root.classList.contains('theme-light')?'light':saved,false);
 theme?.addEventListener('click',()=>applyTheme(root.classList.contains('theme-light')?'dark':'light'));
 const overlay=$('.search-overlay'), searchOpen=$('.search-toggle'), close=$('.close-search');
 if(overlay&&searchOpen){searchOpen.addEventListener('click',()=>{overlay.classList.add('open');overlay.setAttribute('aria-hidden','false');$('#site-search')?.focus()});}
 if(overlay&&close){close.addEventListener('click',()=>{overlay.classList.remove('open');overlay.setAttribute('aria-hidden','true')});overlay.addEventListener('click',e=>{if(e.target===overlay){overlay.classList.remove('open');overlay.setAttribute('aria-hidden','true')}});}
 const revealTargets=$$('.article-card,.reveal,.trust-item,.topic,.feature-box,.about-card');
 if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}}),{threshold:.08});revealTargets.forEach((el,i)=>{el.style.setProperty('--delay',`${(i%4)*70}ms`);observer.observe(el)});}else revealTargets.forEach(el=>el.classList.add('visible'));
 const input=$('#site-search'), cards=$$('.article-card'), chips=$$('.filter-chip'), empty=$('.empty-state'); let active='All';
 function filter(){const q=(input?.value||'').trim().toLowerCase();let count=0;cards.forEach(card=>{const text=(card.dataset.search||'').toLowerCase();const cat=card.dataset.category||'';const ok=(!q||text.includes(q))&&(active==='All'||cat===active);card.hidden=!ok;if(ok)count++;});if(empty)empty.classList.toggle('show',count===0);}
 input?.addEventListener('input',filter); chips.forEach(chip=>chip.addEventListener('click',()=>{chips.forEach(c=>c.classList.remove('active'));chip.classList.add('active');active=chip.dataset.filter;filter()}));
 $$('form[data-demo-form]').forEach(form=>form.addEventListener('submit',e=>{e.preventDefault();const msg=$('.form-note',form);if(msg)msg.textContent='Thanks! Connect this form to your email platform before collecting subscriptions.';form.reset()}));
 const header=$('.header'), top=$('.top-button');function scrollUI(){const y=window.scrollY;if(header)header.classList.toggle('scrolled',y>15);if(top)top.classList.toggle('show',y>450);const bar=$('.progress-bar');if(bar){const max=document.documentElement.scrollHeight-window.innerHeight;bar.style.width=(max>0?Math.min(100,y/max*100):0)+'%';}}window.addEventListener('scroll',scrollUI,{passive:true});scrollUI();top?.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
 const share=$('[data-share]');share?.addEventListener('click',async()=>{const data={title:document.title,text:$('.article-dek')?.textContent||'',url:location.href};try{if(navigator.share)await navigator.share(data);else if(navigator.clipboard){await navigator.clipboard.writeText(location.href);share.textContent='Link copied ✓';}}catch(e){}});
 const toc=$('.toc-links');let headings=$$('.article-copy h2');if(!headings.length)headings=$$('.article-body h2');if(toc&&headings.length){headings.forEach((h,i)=>{const id='section-'+(i+1);h.id=id;const a=document.createElement('a');a.href='#'+id;a.textContent=h.textContent;toc.appendChild(a)})}
 const countEls=$$('.count-up');const reduceMotion=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const animateCount=el=>{const target=Number(el.dataset.count||0);if(reduceMotion||!Number.isFinite(target)){el.textContent=String(target);return;}const duration=850;const start=performance.now();const frame=now=>{const t=Math.min(1,(now-start)/duration);el.textContent=String(Math.round(target*(1-Math.pow(1-t,3))));if(t<1)requestAnimationFrame(frame);};requestAnimationFrame(frame);};
 if(countEls.length&&'IntersectionObserver' in window){const countObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){animateCount(entry.target);countObserver.unobserve(entry.target);}}),{threshold:.5});countEls.forEach(el=>countObserver.observe(el));}else countEls.forEach(animateCount);
 const year=$('[data-year]');if(year)year.textContent=new Date().getFullYear();
})();